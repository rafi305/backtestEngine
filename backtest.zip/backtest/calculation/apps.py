from django.apps import AppConfig


class CalculationConfig(AppConfig):
    name = 'calculation'
