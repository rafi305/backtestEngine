
import calculation.Functions_db as f
import pyodbc as ms
import calculation.Functions_Calculate as f_c
from itertools import chain
import datetime

#filename="C://Backtest//BacktestInput.csv"
#filename="C://Backtest//BTInput1.csv"
#filename="C://Backtest//bactest 3.csv"
#2periods
#filename="C://Backtest//BacktestInput(delisted).csv"
#filename="C://Backtest//BacktestInputFYSMID.csv"
#print(filename)
#conn1 = ms.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER=204.80.90.133;DATABASE=FDS_Datafeeds;UID=sa;PWD=f0r3z@786')
#conn1 = ms.connect('DRIVER={ODBC Driver 11 for SQL Server};SERVER=65.0.33.214;DATABASE=FDS_Datafeeds;UID=sa;PWD=Indxx@1234')
#cursor1 = conn1.cursor()

#Error,Warning,D_Data,D_Date,D_ISIN,last_Period,D_RIC_ISIN = f.Validate_Read_CSV(filename,cursor1,"ISIN")
#print(Error)

def getList(dict): 
    list1 = [] 
    for key in dict.keys(): 
        list1.append(key)      
    return list1
def Cal_Index(D_Index,D_Data,D_ISIN,D_Date,D_RIC_ISIN,last_Period,cursor1):
    #print(D_Index)
    Index_List = list()
    #print("inside cal_Index")
    Constituents_List = list()
    for period in D_Data:
        #print("inside cal_Index")
        Index_Currency = D_Index["Currency"]
        format_str = '%m/%d/%Y'
        S_Date = datetime.datetime.strptime(D_Date[period+"_START"], format_str).date()- datetime.timedelta(days=0)
        if S_Date.weekday()==5:
            S_Date = S_Date - datetime.timedelta(days=1)
        S_Date_Minus_Five = datetime.datetime.strptime(D_Date[period+"_START"], format_str).date()- datetime.timedelta(days=5)
        E_Date = datetime.datetime.strptime(D_Date[period+"_END"], format_str).date()- datetime.timedelta(days=0)
       
        i=0

        D_Index["M_Cap_PR"],D_Index["M_Cap_TR"],D_Index["M_Cap_NTR"]=D_Index["MV"],D_Index["MV"],D_Index["MV"]
        D_Index["Index_Value_PR"], D_Index["Index_Value_TR"],D_Index["Index_Value_NTR"]= D_Index["IV"],D_Index["IV"],D_Index["IV"]
        Divisor = D_Index["MV"]/D_Index["IV"]
        D_Index["Divisor_PR"], D_Index["Divisor_TR"],D_Index["Divisor_NTR"]=Divisor,Divisor,Divisor
       
        D_Price,D_LastDate,currency_list,D_ISIN_Currency = f.Get_PRICE(cursor1,D_ISIN[period],S_Date_Minus_Five.strftime("%x"),E_Date.strftime("%x"),D_Index["Identifier"])
        f.Set_TR_Price(D_Date,D_RIC_ISIN,last_Period,D_Price)
        currency_list.append(Index_Currency)
        Ex_Rate = f.Get_Currency(cursor1,currency_list,S_Date_Minus_Five.strftime("%x"),E_Date.strftime("%x"))
        Tax_Rate = f.Get_TAX(cursor1)
        D_CA = f.Get_CA(cursor1,D_ISIN[period],S_Date.strftime("%x"),E_Date.strftime("%x"),D_Index["Identifier"])
        #print(D_CA)
        
        Latest_Price={}
        Latest_Ex_Rate={}

        while S_Date_Minus_Five <= E_Date:
            #print(D_Price)
            #print(Ex_Rate)
            f_c.Set_Latest_Ex_Rate(Index_Currency,D_Data[period],Ex_Rate,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),D_ISIN_Currency)
            f_c.Set_Latest_Price(D_Data[period],D_Price,Latest_Price,S_Date_Minus_Five.strftime("%x"))
            if S_Date_Minus_Five>=S_Date:
                if i==0:
                    #print("Calculate Shares")
                    f_c.Cal_Shares(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Constituents_List,period,Tax_Rate,D_ISIN_Currency)
                else:
                    print_flag = GetFlag(D_Index["DCFO"],S_Date_Minus_Five.strftime("%x"),D_Date[period+'_END'])
                    M_Cap = f_c.Cal_Index_Close(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Constituents_List,period,Tax_Rate,D_ISIN_Currency,print_flag)
                f_c.Fill_Index_Report_Data(D_Index,Index_List,period,S_Date_Minus_Five)
                i += 1
                
            if S_Date_Minus_Five.weekday()==4:
                S_Date_Minus_Five = S_Date_Minus_Five + datetime.timedelta(days=3)
            else:
                S_Date_Minus_Five = S_Date_Minus_Five + datetime.timedelta(days=1)

            #print(S_Date_Minus_Five)
            #print(S_Date)
            if S_Date_Minus_Five>S_Date and i!=0:
                f_c.Delist(D_Data[period],S_Date_Minus_Five.strftime("%x"),D_LastDate,E_Date.strftime("%x"))
                f_c.Cal_Index_Open(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),Tax_Rate,D_ISIN_Currency,Ex_Rate,D_CA)
            #    f_c.Adjust_CA(D_Index,D_Data[period],Latest_Price,Latest_Ex_Rate,S_Date_Minus_Five.strftime("%x"),D_ISIN_Currency,D_CA,Ex_Rate)
    files = f_c.Print_Reports(Index_List,Constituents_List)
    return files

def GetFlag(option,date,date_end):
    if option =="ND":
        return 0
    elif option =="CD":
        return 1
    elif option =="EDD":
        #endDate = date_end.strftime("%x")
        format_str = '%m/%d/%Y'
        endDate = datetime.datetime.strptime(date_end, format_str).date()
        
        #print(endDate.strftime("%x"))
        #print(endDate.strftime("%x") +"VS"+date)
        if endDate.strftime("%x") ==date:
            #print(endDate.strftime("%x") +"VS"+date)
            return 1
        else :
            return 0
        
    
D_Index = {}
D_Index["Identifier"] = "ISIN"
D_Index["IV"] = 1000
D_Index["MV"] = 100000
D_Index["Currency"] = "USD"
D_Index["Adjustment"] = "DA"#"SA"
D_Index["DCFO"] = "CD"#"ND"#"CD","EDD"

#Cal_Index(D_Index,D_Data,D_ISIN,D_Date,D_RIC_ISIN,last_Period)
#cursor1.close()
#conn1.close()


